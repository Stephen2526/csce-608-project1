<!DOCTYPE html>

<!-- paulirish.com/2008/conditional-stylesheets-vs-css-hacks-answer-neither/ -->
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
<?php include("includes/head.html");?>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {box-sizing:border-box}
body {font-family: Verdana,sans-serif;}
.mySlides {display:none}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 13px;
  width: 13px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4}
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4}
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}
</style>
</head>

<body>	
	<div class="row">
		<div class="twelve columns">
			<img src="img/xiaomi_logo.png">
			<a class="head_nav_a" >Welsocm to DSLR Camera</a>
            <span>|</span>
            <a class="head_nav_a"  href="http://www.bestbuy.com/site/buying-guides/dslr-camera-buying-guide/pcmcat329300050005.c?id=pcmcat329300050005" style= "text-decoration: none">Tips for DSLR Camera</a>
			<ul class="nav-bar">				
				<li class="active"><a href="javascript:;">Home</a></li>
				<li><a href="add_new.php">Add photos</a></li>
				<li><a href="search.php">Search photos</a></li>
				<li><a href="select.php">View all the Photographers</a></li>
			</ul>
		</div>
	</div>
	
	
	
	<div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 4</div>
  <img src="imgc/4nikonD3200.png" style="width:100%">
  <div class="text">NikonD3200</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 4</div>
  <img src="imgc/A99Sony.png" style="width:100%">
  <div class="text">Sony A99</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 4</div>
  <img src="imgc/3Canoneosrebelt5i.png" style="width:100%">
  <div class="text">Canon EOS Rebel t5i</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">4 / 4</div>
  <img src="imgc/canoneos50D2.png" style="width:100%">
  <div class="text">Canon EOS 50D</div>
</div>

</div>
<br>

<div style="text-align:center">
  <span class="dot"></span>
  <span class="dot"></span>
  <span class="dot"></span>
  <span class="dot"></span>
</div>

<script>
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex> slides.length) {slideIndex = 1}
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 2000); // Change image every 2 seconds
}
</script>

	

		
	<div class="row">
		<div class="twelve columns">
			<div class="row">
				<div class="eight columns">
				    <br />
					<h3>Kelly's Photo Album: DBMS for photos</h3>
					
					<h5>
					Kelly's Photo Album is a DBMS for photos, along with the photographers, the cameras they are using and the log file recoding the date when the photo is being shot.The schema is shown below.
					<br /><br />
					There are five categories of photos: pets, people, building, automotive, and nature.
					</h5>
					<img src="images/db_schema.png" height="3300" width="3800"/>
										
				</div>
		
				<div class="four columns">
					<h4>5 catagories of  photos</h4>
					<img src="images/pets.png" />
					<img src="images/people.png" />
					<img src="images/building.png" />
					<img src="images/automotive.png" />
					<img src="images/nature.png" />				
					<br />
				</div>
			</div>
		</div>
	</div>
	
	<?php include("includes/footer.html");?>
</body>
</html>