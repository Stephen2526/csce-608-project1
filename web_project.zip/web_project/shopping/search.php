<!DOCTYPE html>

<!-- paulirish.com/2008/conditional-stylesheets-vs-css-hacks-answer-neither/ -->
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
<?php include("includes/head.html");?>

<body>
	
	
	<div class="container">
		<?php 
			include("includes/header.html");
			//connect to databse
			include("php/db_conn.php")
		?>
		
		<div class="row">
			<div class="twelve columns">
				<ul class="nav-bar">
					<li><a href="index.php">Home</a></li>
					<li><a href="add_new.php">Add photos</a></li>
					<li class="active"><a href="javascript:;">Search photos</a></li>
					<li><a href="select.php">View all the Photographers</a></li>
				</ul>
			</div>
		</div>
				
		<div class="row">
			<div class="twelve columns">
				<h3>Search photos</h3>
				<div class="row">
					<div class="three columns" id="leftSearchContainer">
						<p id="secName">Search results by</p> 	
						<form action="search.php" method="post" class="custom">
							<p class="subSecName">brand:</p>
								<div id="BrdCheckboxContainer" class="custom">
									<div class="checkbox">
									  <label><input type="checkbox" value="nikon" name="brd[]">Nikon</label>
									</div>
									<div class="checkbox">
									  <label><input type="checkbox" value="canon" name="brd[]">Canon</label>
									</div>
									<div class="checkbox">
									  <label><input type="checkbox" value="olympus" name="brd[]">Olympus</label>
									</div>
									<div class="checkbox">
									  <label><input type="checkbox" value="sony" name="brd[]">Sony</label>
									</div>
									<div class="checkbox">
									  <label><input type="checkbox" value="fujifilm" name="brd[]">Fujifilm</label>
									</div>
								</div>
							
							<p class="subSecName">price:</p>
								<!--
									<div id="rslnRatio">
										<input type="radio" name="rsln_sml" value="small"> small<br>
										<input type="radio" name="rsln_sml" value="medium"> medium<br>
										<input type="radio" name="rsln_sml" value="large"> large
									</div>
									<br>
								-->
								<div id="priceEnter">
									<label>between:</label>
									<input type="text" name="price_l" placeholder="width">
									
									<label>and</label>
									<input type="text" name="price_h" placeholder="height">
								</div>
							<p class="subSecName">comment:</p>
							<div id="comCheckboxContainer" class="custom">
								<div class="checkbox">
								  <label><input type="checkbox" value="1" name="com[]">1</label>
								</div>
								<div class="checkbox">
								  <label><input type="checkbox" value="2" name="com[]">2</label>
								</div>
								<div class="checkbox">
								  <label><input type="checkbox" value="3" name="com[]">3</label>
								</div>
								<div class="checkbox">
								  <label><input type="checkbox" value="4" name="com[]">4</label>
								</div>
								<div class="checkbox">
								  <label><input type="checkbox" value="5" name="com[]">5</label>
								</div>
							</div>
								
							<p class="subSecName">model year:</p>
							<?php
								$qry_year = "select distinct model_y from cameras ORDER BY model_y ASC";
								$data_year = mysql_query($qry_year, $mysql);
								//handle query error
								if($data_year == false){
									$message = "Failed to fetch photographer names";
									echo "<script type='text/javascript'>alert('$message');</script>";
								}
								echo "<div id=\"yearCheckboxContainer\">";
								while ($record = mysql_fetch_array($data_year)) {
									echo "<div class=\"checkbox\">\n"; 
									echo  "<label><input type=\"checkbox\" value=\"" . $record['model_y'] . "\" name=\"year[]\">" . $record['model_y'] . "</label>\n</div>\n";
								}
								echo "</div>";
							?>
							
							
							<div style="margin-top:10px;">
								<input type='submit' name='search' value = 'search items'>
							</div>
						</form>					
					</div>
			
					<div class="nine columns">
					<p id="secName">Search results</p>
					<?php
						if (isset($_POST['search'])) {
							$brand_qry = "select id_camera from cameras";
							$price_qry = "select id_camera from cameras";
							$comment_qry = "select id_camera from cameras";
							$year_qry = "select id_camera from cameras";
							$whole_qry = "select * from cameras";
							
							if (!isset($_POST['brd']) && empty($_POST['price_l']) && empty($_POST['price_h']) && !isset($_POST['com']) && !isset($_POST['year'])) {
								echo "<p>Please select something to search.</p>";
							}
							else {
								//define conditions
								if (isset($_POST['brd'])) {
									$brd_cons_len = sizeof($_POST['brd']);
									$brand_qry .= " where (brand='" . $_POST['brd'][0] . "'";
									$i = 1;
									while ($i < $brd_cons_len) {
										$brand_qry .= " or brand='" . $_POST['brd'][$i] . "'";
										$i++;
										
									}
									$brand_qry .= ")";
									//echo $ctgy_cons . "<br><br>";
								}
							
								if (!empty($_POST['price_l']) && !empty($_POST['price_h'])) {
									//price cons
									$price_qry .= " where (price between " . $_POST['price'][0] . " and " . $_POST['price'][1] . ")";
									
									//echo $phoger_id_qry . "<br><br>";
								}
								
								if (isset($_POST['com'])) {
									$com_cons_len = sizeof($_POST['com']);
									$comment_qry .= " where (comments=" . $_POST['com'][0];
									$i = 1;
									while ($i < $com_cons_len) {
										$comment_qry .= " or comments=" . $_POST['com'][$i];
										$i++;
										
									}
									$comment_qry .= ")";
									//echo $ctgy_cons . "<br><br>";
								}
								
								if (isset($_POST['year'])) {
									$year_cons_len = sizeof($_POST['year']);
									$year_qry .= " where (model_y='" . $_POST['year'][0] . "'";
									$i = 1;
									while ($i < $year_cons_len) {
										$year_qry .= " or model_y='" . $_POST['year'][$i] . "'";
										$i++;
										
									}
									$year_qry .= ")";
									//echo $ctgy_cons . "<br><br>";
								}
								
								$whole_qry .= " where id_camera in (" . $brand_qry . ") and id_camera in (" . $price_qry . ") and id_camera in (" . $comment_qry .") and id_camera in (" . $year_qry . ")";
								//echo $whole_qry . "<br><br>";
								
								$mydata = mysql_query($whole_qry, $mysql);
								
								$record = mysql_fetch_array($mydata);
								if ($record == NULL) {
									echo "<p>No results!</p>";
								}
								while($record = mysql_fetch_array($mydata))
								{
									echo "<div class=\"gallery\">\n"; 
									echo "<div class=\"photo\">\n"; 
									echo "<a href=\"contact.php?id_camera=" . $record['id_camera'] . "\"><img src=\"" . $record['ext_front'] . "\" alt=\"not available\"></a>\n"; 
									echo "<p><a href=\"#\"></a></p>"; 
									echo "</div>";
									echo "</div>";
								}
							}
						}
					?>					
					</div>
				</div>
			</div>
		</div>
		<?php include("includes/footer.html");?>
	</div>
	
	
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
    <link rel="stylesheet" href="stylesheets/jquery.timepicker.css">
    <script src="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.3/jquery.timepicker.min.js"></script>
	
	<script type="text/javascript" src="javascripts/zebra_datepicker.js"></script>
	<link rel="stylesheet" href="stylesheets/default.css" type="text/css">
	
	<script type="text/javascript">
		$(document).ready(function() {
			$("input.timepicker").timepicker(
					{timeFormat: 'h:mm p',
					interval: 30,
					defaultTime: '12',
					startTime: '00:00',
					dynamic: false,
					dropdown: true,
					scrollbar: true
				    });
			$('input.datepicker').Zebra_DatePicker();
		});
	</script>
</body>
</html>