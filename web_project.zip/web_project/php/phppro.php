<?php 
    $site['title']='GallaryDBSM';
    $site['copyright']='2013';
    $site['name'] = 'gallary.com';
    
    
    $nav = array(
        'home' => 'Home Page',
        'hosts'=>'Our Hosts',
        );
?>