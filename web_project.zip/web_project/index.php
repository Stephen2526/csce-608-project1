<!DOCTYPE html>

<!-- paulirish.com/2008/conditional-stylesheets-vs-css-hacks-answer-neither/ -->
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
<?php include("includes/head.html");?>

<body>
	<?php include("includes/header.html");?>
	
	<div class="row">
		<div class="twelve columns">
			<ul class="nav-bar">
				<li class="active"><a href="javascript:;">Home</a></li>
				<li><a href="add_new.php">Add photos</a></li>
				<li><a href="search.php">Search photos</a></li>
				<li><a href="select.php">View all the Photographers</a></li>
			</ul>
		</div>
	</div>
		
	<div class="row">
		<div class="twelve columns">
			<div class="row">
				<div class="eight columns">
				    <br />
					<h3>Kelly's Photo Album: DBMS for photos</h3>
					
					<h5>
					Kelly's Photo Album is a DBMS for photos, along with the photographers, the cameras they are using and the log file recoding the date when the photo is being shot.The schema is shown below.
					<br /><br />
					There are five categories of photos: pets, people, building, automotive, and nature.
					</h5>
					<img src="images/db_schema.png" height="3300" width="3800"/>
										
				</div>
		
				<div class="four columns">
					<h4>5 catagories of  photos</h4>
					<img src="images/pets.png" />
					<img src="images/people.png" />
					<img src="images/building.png" />
					<img src="images/automotive.png" />
					<img src="images/nature.png" />				
					<br />
				</div>
			</div>
		</div>
	</div>
	
	<?php include("includes/footer.html");?>
</body>
</html>