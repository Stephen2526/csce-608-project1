<!DOCTYPE html>

<!-- paulirish.com/2008/conditional-stylesheets-vs-css-hacks-answer-neither/ -->
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
<?php include("includes/head.html");?>

<body>
	
	
	<div class="container">
		<?php 
			include("includes/header.html");
			//connect to databse
			include("php/db_conn.php")
		?>
		
		<div class="row">
			<div class="twelve columns">
				<ul class="nav-bar">
					<li><a href="index.php">Home</a></li>
					<li><a href="add_new.php">Add photos</a></li>
					<li class="active"><a href="javascript:;">Search photos</a></li>
					<li><a href="select.php">View all the Photographers</a></li>
				</ul>
			</div>
		</div>
				
		<div class="row">
			<div class="twelve columns">
				<h3>Search photos</h3>
				<div class="row">
					<div class="three columns" id="leftSearchContainer">
						<p id="secName">Search results by</p> 	
						<form action="search.php" method="post" class="custom">
							<p class="subSecName">categary:</p>
								<div id="ctyCheckboxContainer" class="custom">
									<div class="checkbox">
									  <label><input type="checkbox" value="pets" name="ctgy[]">pets</label>
									</div>
									<div class="checkbox">
									  <label><input type="checkbox" value="human" name="ctgy[]">human</label>
									</div>
									<div class="checkbox">
									  <label><input type="checkbox" value="architecture" name="ctgy[]">arch</label>
									</div>
									<div class="checkbox">
									  <label><input type="checkbox" value="vehicle" name="ctgy[]">vehicle</label>
									</div>
									<div class="checkbox">
									  <label><input type="checkbox" value="nature" name="ctgy[]">nature</label>
									</div>
								</div>
							<!--
							<p class="subSecName">resolution:</p>
								<div id="rslnRatio">
									<input type="radio" name="rsln_sml" value="small"> small<br>
									<input type="radio" name="rsln_sml" value="medium"> medium<br>
									<input type="radio" name="rsln_sml" value="large"> large
								</div>
								<br>
								<div id="rslnEnter">
									<label>at least:</label>
									<input type="text" name="rsln_w" placeholder="width">
									
									<label>*</label>
									<input type="text" name="rsln_h" placeholder="height">
								</div>
							<p class="subSecName">dpi:</p>
								<div id="dpiCheckboxContainer" class="custom">
									<div class="checkbox">
									  <label><input type="checkbox" value="20" name="dpi[]">20</label>
									</div>
									<div class="checkbox">
									  <label><input type="checkbox" value="96" name="dpi[]">96</label>
									</div>
									<div class="checkbox">
									  <label><input type="checkbox" value="120" name="dpi[]">120</label>
									</div>
									<div class="checkbox">
									  <label><input type="checkbox" value="150" name="dpi[]">150</label>
									</div>
									<div class="checkbox">
									  <label><input type="checkbox" value="200" name="dpi[]">200</label>
									</div>
									<div class="checkbox">
									  <label><input type="checkbox" value="300" name="dpi[]">300</label>
									</div>
									<div class="checkbox">
									  <label><input type="checkbox" value="600" name="dpi[]">600</label>
									</div>
								</div>
								
								<p class="subSecName">date:</p>
								<input type="text" class="datepicker" name="date" placeholder="">
							<p class="subSecName">weather:</p>
							<div id="weatCheckboxContainer" class="custom">
								<div class="checkbox">
								  <label><input type="checkbox" value="foggy" name="wea[]">foggy</label>
								</div>
								<div class="checkbox">
								  <label><input type="checkbox" value="cloudy" name="wea[]">cloudy</label>
								</div>
								<div class="checkbox">
								  <label><input type="checkbox" value="rainy" name="wea[]">rainy</label>
								</div>
								<div class="checkbox">
								  <label><input type="checkbox" value="clear" name="wea[]">clear</label>
								</div>
								<div class="checkbox">
								  <label><input type="checkbox" value="sunny" name="wea[]">sunny</label>
								</div>
								<div class="checkbox">
								  <label><input type="checkbox" value="snowy" name="wea[]">snowy</label>
								</div>
								<div class="checkbox">
								  <label><input type="checkbox" value="lightening" name="wea[]">lightening</label>
								</div>
							</div>
								
							-->	
							
							<p class="subSecName">photographer:</p>
								<?php
									$qry_phoger = "select name from phogers";
									$data_phogers = mysql_query($qry_phoger, $mysql);
									//handle query error
									if($data_phogers == false){
										$message = "Failed to fetch photographer names";
										echo "<script type='text/javascript'>alert('$message');</script>";
									}
									echo "<div id=\"phogerCheckboxContainer\">";
									while ($record = mysql_fetch_array($data_phogers)) {
										echo "<div class=\"checkbox\">\n"; 
										echo  "<label><input type=\"checkbox\" value=\"" . $record['name'] . "\" name=\"phoger_name[]\">" . $record['name'] . "</label>\n</div>\n";
									}
									echo "</div>";
								?>
							
							<div style="margin-top:10px;">
								<input type='submit' name='search' value = 'search items'>
							</div>
						</form>					
					</div>
			
					<div class="nine columns">
					<p id="secName">Search results</p>
					<?php
						if (isset($_POST['search'])) {
							$ctgy_cons = "select id_img from images";
							$phoger_id_qry = "select id_phoger from phogers";
							$whole_qry = "select * from images";
							
							if (!isset($_POST['ctgy']) && !isset($_POST['phoger_name'])) {
								echo "<p>Please select something to search.</p>";
							}
							else {
								//define conditions
								if (isset($_POST['ctgy'])) {
									$ctgy_cons_len = sizeof($_POST['ctgy']);
									$ctgy_cons .= " where (ctgy='" . $_POST['ctgy'][0] . "'";
									$i = 1;
									while ($i < $ctgy_cons_len) {
										$ctgy_cons .= " or ctgy='" . $_POST['ctgy'][$i] . "'";
										$i++;
										
									}
									$ctgy_cons .= ")";
									//echo $ctgy_cons . "<br><br>";
								}
							
								if (isset($_POST['phoger_name'])) {
									$phoger_cons_len = sizeof($_POST['phoger_name']);
									//find id_phoger
									$phoger_id_qry .= " where (name='" . $_POST['phoger_name'][0] . "'";
									
									$i = 1;
									while ($i < $phoger_cons_len) {
										$phoger_id_qry .= " or name='" . $_POST['phoger_name'][$i] ."'";
										$i++;
									}
									$phoger_id_qry .=")"; 
									//echo $phoger_id_qry . "<br><br>";
								}
								
								$whole_qry .= " where id_img in (" . $ctgy_cons . ") and id_phoger in (" . $phoger_id_qry . ")";
								//echo $whole_qry . "<br><br>";
								
								
								$mydata = mysql_query($whole_qry, $mysql);
								
								$record = mysql_fetch_array($mydata);
								if ($record == NULL) {
									echo "<p>No results!</p>";
								}
								
								while($record = mysql_fetch_array($mydata))
								{
									echo "<div class=\"gallery\">\n"; 
									echo "<div class=\"photo\">\n"; 
									echo "<a href=\"contact.php?id_img=" . $record['id_img'] . "\"><img src=\"" . $record['file'] . "\" alt=\"not available\"></a>\n"; 
									echo "<p><a href=\"#\"></a></p>"; 
									echo "</div>";
									echo "</div>";
								}
							}
						}
					?>					
					</div>
				</div>
			</div>
		</div>
		<?php include("includes/footer.html");?>
	</div>
	
	
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
    <link rel="stylesheet" href="stylesheets/jquery.timepicker.css">
    <script src="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.3/jquery.timepicker.min.js"></script>
	
	<script type="text/javascript" src="javascripts/zebra_datepicker.js"></script>
	<link rel="stylesheet" href="stylesheets/default.css" type="text/css">
	
	<script type="text/javascript">
		$(document).ready(function() {
			$("input.timepicker").timepicker(
					{timeFormat: 'h:mm p',
					interval: 30,
					defaultTime: '12',
					startTime: '00:00',
					dynamic: false,
					dropdown: true,
					scrollbar: true
				    });
			$('input.datepicker').Zebra_DatePicker();
		});
	</script>
</body>
</html>